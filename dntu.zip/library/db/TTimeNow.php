<?php 

class TTimeNow{
	
}