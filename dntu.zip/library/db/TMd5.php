<?php 

class TMd5{
	public $value;
	public function __construct($value){
		$this->value=$value;
	}
}