<?php 
require_once SYSTEM_PATH."db/TDatabase.php";

class Select extends TDatabase{
	
}