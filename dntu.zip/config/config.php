<?php 

return array(
	'default'=>array(
		'controller'=>'index',
		'action'=>'index'
	),
	'layout'=>'home/index',
	'db'=>array(
		"driver"=>"mysql",
		"host"=>"localhost",
		"dbname"=>"tu_dien",
		"username"=>"root",
		"password"=>"",
		"charset"=>"utf8",
		"time_zone"=>"+7:00"
	)
);